<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('dashboard');
});

//Display Index Page
Route::get('/transaksi', 'TransaksiController@index');


// Populate Data in Edit Modal Form
Route::get('Transaksi/{transaksi_id?}', 'TransaksiController@show');


//create New transaksi
Route::post('transaksi', 'TransaksiController@store');


// update Existing transaksi
Route::put('transaksi/{transaksi_id}', 'TransaksiController@update');


// delete transaksi
Route::delete('transaksi/{transaksi_id}', 'TransaksiController@destroy');

Route::resource('/siswa', 'SiswaController');
Route::post('/siswa/import_excel', 'SiswaController@import_excel');
Route::resource('/kategori', 'KategoriController');

